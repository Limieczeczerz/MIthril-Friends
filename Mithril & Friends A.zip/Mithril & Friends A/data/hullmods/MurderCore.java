package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class MurderCore extends BaseHullMod {
	public static float BONUS_PERCENT = 10f;
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getEnergyWeaponDamageMult().modifyPercent(id, BONUS_PERCENT);
		stats.getMissileWeaponDamageMult().modifyPercent(id, BONUS_PERCENT);
		stats.getBallisticWeaponDamageMult().modifyPercent(id, BONUS_PERCENT);
	}
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) BONUS_PERCENT + "%";
		return null;
	}
}









